def activity_selection(activities):
    sorted_activities = sorted(activities, key=lambda x: x[1])
    selected = []
    last_end_time = 0

    for start, end in sorted_activities:
        if start >= last_end_time:
            selected.append((start, end))
            last_end_time = end

    return selected

"Test cases"
activities1 = [(1, 3), (2, 5), (3, 9), (6, 8), (8, 11)]
activities2 = [(0, 6), (1, 4), (3, 5), (5, 7), (5, 9), (8, 9)]
activities3 = [(10, 20), (12, 25), (20, 30)]

print("Test Case 1:", activity_selection(activities1))  
print("Test Case 2:", activity_selection(activities2))
print("Test Case 3:", activity_selection(activities3)) 
