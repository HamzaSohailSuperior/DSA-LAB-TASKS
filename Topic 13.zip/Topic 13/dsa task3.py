class DisjointSet:
    def __init__(self, n):
        self.parent = list(range(n + 1))  # 1-indexed
        self.rank = [0] * (n + 1)

    def find(self, u):
        if self.parent[u] != u:
            self.parent[u] = self.find(self.parent[u])  # Path compression
        return self.parent[u]

    def union(self, u, v):
        root_u = self.find(u)
        root_v = self.find(v)

        if root_u == root_v:
            return False  # Already connected, would create a cycle

        # Union by rank
        if self.rank[root_u] < self.rank[root_v]:
            self.parent[root_u] = root_v
        elif self.rank[root_u] > self.rank[root_v]:
            self.parent[root_v] = root_u
        else:
            self.parent[root_v] = root_u
            self.rank[root_u] += 1

        return True

# Kruskal's Algorithm
def kruskal(edges, num_nodes):
    # Step 1: Sort edges by weight
    edges.sort(key=lambda x: x[2])
    ds = DisjointSet(num_nodes)
    mst = []

    for u, v, weight in edges:
        if ds.union(u, v):
            mst.append((u, v, weight))

        if len(mst) == num_nodes - 1:
            break

    return mst

# Example input
edges = [(1, 2, 4), (2, 3, 1), (1, 3, 3), (3, 4, 2)]
num_nodes = 4
mst = kruskal(edges, num_nodes)
print("Minimum Spanning Tree:", mst)
