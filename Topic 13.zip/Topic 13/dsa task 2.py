import heapq
from collections import Counter, namedtuple

"Define a node class"
class Node(namedtuple("Node", ["char", "freq", "left", "right"])):
    def __lt__(self, other):  # for priority queue
        return self.freq < other.freq

"Function to build Huffman Tree"
def build_huffman_tree(freq_map):
    heap = [Node(char, freq, None, None) for char, freq in freq_map.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged = Node(None, left.freq + right.freq, left, right)
        heapq.heappush(heap, merged)

    return heap[0]

"Function to generate codes from Huffman Tree"
def generate_codes(node, prefix="", code_map={}):
    if node is None:
        return

    if node.char is not None:
        code_map[node.char] = prefix
    else:
        generate_codes(node.left, prefix + "0", code_map)
        generate_codes(node.right, prefix + "1", code_map)

    return code_map

"Huffman encoding function"
def huffman_encoding(text):
    freq_map = Counter(text)
    root = build_huffman_tree(freq_map)
    codes = generate_codes(root)

    encoded_text = ''.join(codes[char] for char in text)
    original_bits = len(text) * 8
    compressed_bits = len(encoded_text)

    print("Original size:", original_bits, "bits")
    print("Compressed size:", compressed_bits, "bits")
    print("Compression Ratio: {:.2f}%".format(100 * compressed_bits / original_bits))

    return codes

"Example usage"
text = "hello greedy"
codes = huffman_encoding(text)
print("Huffman Codes:", codes)
