def permute(s):
    def backtrack(start):
        if start == len(chars):
            permutations.append("".join(chars))
            return

        seen = set()
        for i in range(start, len(chars)):
            if chars[i] in seen:
                continue
            seen.add(chars[i])
            chars[start], chars[i] = chars[i], chars[start]  # Swap
            backtrack(start + 1)
            chars[start], chars[i] = chars[i], chars[start]  # Backtrack

    permutations = []
    chars = list(s)
    backtrack(0)
    return permutations

# Example usage
print(permute("ABC"))  # Output: ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA']
