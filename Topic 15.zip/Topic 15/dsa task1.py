def solve_n_queens(n):
    solutions = []
    board = ["." * n for _ in range(n)]

    def is_safe(row, col, diagonals, anti_diagonals, cols):
        return col not in cols and (row - col) not in diagonals and (row + col) not in anti_diagonals

    def backtrack(row=0, diagonals=set(), anti_diagonals=set(), cols=set(), state=[]):
        if row == n:
            solutions.append(state[:])
            return

        for col in range(n):
            if is_safe(row, col, diagonals, anti_diagonals, cols):
                cols.add(col)
                diagonals.add(row - col)
                anti_diagonals.add(row + col)

                new_row = "." * col + "Q" + "." * (n - col - 1)
                backtrack(row + 1, diagonals, anti_diagonals, cols, state + [new_row])

                cols.remove(col)
                diagonals.remove(row - col)
                anti_diagonals.remove(row + col)

    backtrack()
    return solutions

# Example test
solutions = solve_n_queens(4)
for i, sol in enumerate(solutions, 1):
    print(f"Solution {i}:")
    for row in sol:
        print(row)
    print()
