# LCS using recursion with memoization
def lcs_memo(s1, s2):
    memo = {}

    def recurse(i, j):
        if i == len(s1) or j == len(s2):
            return ""
        if (i, j) in memo:
            return memo[(i, j)]

        if s1[i] == s2[j]:
            memo[(i, j)] = s1[i] + recurse(i + 1, j + 1)
        else:
            option1 = recurse(i + 1, j)
            option2 = recurse(i, j + 1)
            memo[(i, j)] = option1 if len(option1) > len(option2) else option2

        return memo[(i, j)]

    return recurse(0, 0)


# LCS using tabulation (bottom-up)
def lcs_tab(s1, s2):
    m, n = len(s1), len(s2)
    dp = [[""] * (n + 1) for _ in range(m + 1)]

    for i in range(m):
        for j in range(n):
            if s1[i] == s2[j]:
                dp[i + 1][j + 1] = dp[i][j] + s1[i]
            else:
                dp[i + 1][j + 1] = max(dp[i + 1][j], dp[i][j + 1], key=len)

    return dp[m][n]


# Test cases
s1 = "AGGTAB"
s2 = "GXTXAYB"
print("LCS (Memoization):", lcs_memo(s1, s2))  # Output: GTAB
print("LCS (Tabulation):", lcs_tab(s1, s2))    # Output: GTAB
