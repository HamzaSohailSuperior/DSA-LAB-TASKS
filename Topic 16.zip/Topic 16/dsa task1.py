from collections import deque

# Recursive DFS
def dfs_recursive(graph, start, visited=None):
    if visited is None:
        visited = []
    visited.append(start)
    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs_recursive(graph, neighbor, visited)
    return visited

# Iterative DFS
def dfs_iterative(graph, start):
    visited = []
    stack = [start]
    while stack:
        node = stack.pop()
        if node not in visited:
            visited.append(node)
            # Add neighbors in reverse order to mimic recursive DFS
            stack.extend(reversed(graph[node]))
    return visited

# Breadth-First Search (BFS)
def bfs(graph, start):
    visited = []
    queue = deque([start])
    while queue:
        node = queue.popleft()
        if node not in visited:
            visited.append(node)
            queue.extend(graph[node])
    return visited

# Example graph
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': ['F'],
    'F': []
}

# Run algorithms
print("DFS (Recursive):", dfs_recursive(graph, 'A'))  # ['A', 'B', 'D', 'E', 'F', 'C']
print("DFS (Iterative):", dfs_iterative(graph, 'A'))  # ['A', 'B', 'D', 'E', 'F', 'C']
print("BFS:", bfs(graph, 'A'))                         # ['A', 'B', 'C', 'D', 'E', 'F']
