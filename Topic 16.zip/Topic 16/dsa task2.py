import heapq

def dijkstra(graph, start):
    # Step 1: Initialize distances
    distances = {node: float('inf') for node in graph}
    distances[start] = 0

    # Step 2: Priority queue for the minimum distance node
    priority_queue = [(0, start)]

    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        # Skip if a better path has already been found
        if current_distance > distances[current_node]:
            continue

        # Step 3: Explore neighbors
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances

# Example input
graph = {
    'A': {'B': 1, 'C': 4},
    'B': {'A': 1, 'C': 2, 'D': 5},
    'C': {'A': 4, 'B': 2, 'D': 1},
    'D': {'B': 5, 'C': 1}
}

# Run the algorithm
shortest_paths = dijkstra(graph, 'A')

# Print the result
print("Shortest distances from node 'A':")
for node, distance in shortest_paths.items():
    print(f"{node}: {distance}")
