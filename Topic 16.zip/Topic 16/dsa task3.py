def detect_cycle_undirected(graph):
    parent = {}

    # Find function with path compression
    def find(node):
        if parent[node] != node:
            parent[node] = find(parent[node])
        return parent[node]

    # Union function
    def union(u, v):
        root_u = find(u)
        root_v = find(v)
        if root_u == root_v:
            return True  # Cycle found
        parent[root_v] = root_u
        return False

    # Initialize parent pointers
    for node in graph:
        parent[node] = node

    visited_edges = set()
    for u in graph:
        for v in graph[u]:
            if (v, u) in visited_edges:  # Avoid double-checking undirected edges
                continue
            visited_edges.add((u, v))
            if union(u, v):
                return True
    return False


# Using DFS + Recursion Stack
def detect_cycle_directed(graph):
    visited = set()
    recursion_stack = set()

    def dfs(node):
        visited.add(node)
        recursion_stack.add(node)

        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                if dfs(neighbor):
                    return True
            elif neighbor in recursion_stack:
                return True  # Cycle found

        recursion_stack.remove(node)
        return False

    for node in graph:
        if node not in visited:
            if dfs(node):
                return True
    return False


# Undirected Graph Example
graph_undirected = {
    'A': ['B', 'C'],
    'B': ['A', 'D'],
    'C': ['A', 'D'],
    'D': ['B', 'C']
}

# Directed Graph Example
graph_directed = {
    'A': ['B'],
    'B': ['C'],
    'C': ['A']
}

# Run Tests
print("Undirected cycle exists:", detect_cycle_undirected(graph_undirected))  # True
print("Directed cycle exists:", detect_cycle_directed(graph_directed))        # True
